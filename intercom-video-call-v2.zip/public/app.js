const socket = io();

const configuration = { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] };
let peerConnection;
let localStream;

const videoContainer = document.getElementById('videoContainer');
const joinBtn = document.getElementById('joinBtn');
const roomIdInput = document.getElementById('roomId');

joinBtn.addEventListener('click', joinRoom);

async function joinRoom() {
  const roomId = roomIdInput.value;
  if (!roomId) return alert('Please enter a room ID');

  try {
    localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    addVideoStream(localStream, true);

    socket.emit('join-room', roomId);

    socket.on('user-connected', () => {
      callUser(roomId);
    });

    socket.on('offer', handleOffer);
    socket.on('answer', handleAnswer);
    socket.on('ice-candidate', handleNewICECandidateMsg);
  } catch (error) {
    console.error('Error joining room:', error);
  }
}

function addVideoStream(stream, isLocal) {
  const video = document.createElement('video');
  video.srcObject = stream;
  video.autoplay = true;
  video.playsInline = true;
  if (isLocal) video.muted = true;
  videoContainer.appendChild(video);
}

async function callUser(roomId) {
  peerConnection = new RTCPeerConnection(configuration);
  localStream.getTracks().forEach(track => peerConnection.addTrack(track, localStream));

  peerConnection.ontrack = handleTrackEvent;
  peerConnection.onicecandidate = (event) => handleICECandidateEvent(event, roomId);

  try {
    const offer = await peerConnection.createOffer();
    await peerConnection.setLocalDescription(offer);
    socket.emit('offer', offer, roomId);
  } catch (error) {
    console.error('Error creating offer:', error);
  }
}

async function handleOffer(offer) {
  peerConnection = new RTCPeerConnection(configuration);
  localStream.getTracks().forEach(track => peerConnection.addTrack(track, localStream));

  peerConnection.ontrack = handleTrackEvent;
  peerConnection.onicecandidate = (event) => handleICECandidateEvent(event, roomIdInput.value);

  await peerConnection.setRemoteDescription(new RTCSessionDescription(offer));
  const answer = await peerConnection.createAnswer();
  await peerConnection.setLocalDescription(answer);
  socket.emit('answer', answer, roomIdInput.value);
}

async function handleAnswer(answer) {
  await peerConnection.setRemoteDescription(new RTCSessionDescription(answer));
}

function handleICECandidateEvent(event, roomId) {
  if (event.candidate) {
    socket.emit('ice-candidate', event.candidate, roomId);
  }
}

async function handleNewICECandidateMsg(candidate) {
  try {
    await peerConnection.addIceCandidate(new RTCIceCandidate(candidate));
  } catch (error) {
    console.error('Error adding ICE candidate:', error);
  }
}

function handleTrackEvent(event) {
  addVideoStream(event.streams[0], false);
}